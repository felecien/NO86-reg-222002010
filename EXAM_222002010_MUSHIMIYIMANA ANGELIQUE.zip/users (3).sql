-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 10:44 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tourism_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `email`, `phone`, `password`) VALUES
(1, 'mushimiyimana', 'angelique', '0789190910', 'm.angenique@gmail.com', '1234'),
(2, '', '', '', '', ''),
(3, '', '', '', '', ''),
(4, 'ewee', 'gggg', 'eeer', 'drrtr', '123'),
(5, 'theophila', 'musabe', '0785788713', 'mtheophila524@gmail', 'mtheophila'),
(6, '', '', '', '', 'c'),
(7, '', '', '', 'ange', 'ange'),
(8, 'ange', 'ange', 'ange', 'ange', 'ange'),
(9, 'ange', 'ange', 'ange', 'ange', 'ange'),
(10, 'ange', 'ange', 'ange', 'ange', 'ange'),
(11, 'anne', 'anne', 'anne', 'anne', 'anne'),
(12, 'ange', 'ssd', 'ssdfdfdf', 'ssss', 'ash'),
(13, 'ange', 'ange', 'ange', 'ange', 'ange'),
(14, 'mushimiyimana ', 'angelique', 'o789190910', '222002010', '222002010'),
(15, 'mushimiyimana', 'mushimiyimana', '0789190910', '222002010', '222002010'),
(16, 'Angelique', 'Angelique', '0780780780', '0780780780', '222002010'),
(17, 'angelique', 'angelique', 'angelique', '222002010', 'angelique');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
